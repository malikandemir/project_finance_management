// import preset from './vendor/filament/support/tailwind.config.preset'

export default {
    // presets: [preset],
    content: ["./resources/views/**/*.blade.php", "./src/**/*.php"],
    darkMode: "class",
    theme: {
        extend: {},
    },
};
